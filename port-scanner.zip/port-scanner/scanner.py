import argparse
import socket
import sys
import threading
import time
from queue import Queue
from typing import List


def scan_port(target_ip: str, port: int, timeout: float) -> bool:
    """Return True if the TCP port is open, otherwise False."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((target_ip, port)) == 0
    except socket.error:
        return False


def worker(
    target_ip: str,
    timeout: float,
    queue: Queue,
    open_ports: List[int],
    lock: threading.Lock,
) -> None:
    while True:
        port = queue.get()
        if port is None:
            queue.task_done()
            break

        if scan_port(target_ip, port, timeout):
            with lock:
                open_ports.append(port)

        queue.task_done()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simple threaded TCP port scanner")
    parser.add_argument("target", help="Target hostname or IP")
    parser.add_argument("--start", type=int, default=1, help="Start port (default: 1)")
    parser.add_argument("--end", type=int, default=1024, help="End port (default: 1024)")
    parser.add_argument("--timeout", type=float, default=0.5, help="Socket timeout in seconds (default: 0.5)")
    parser.add_argument("--threads", type=int, default=50, help="Number of worker threads (default: 50)")
    return parser.parse_args()


def get_service_name(port: int) -> str:
    try:
        return socket.getservbyport(port, "tcp")
    except OSError:
        return "unknown"


def main() -> None:
    args = parse_args()

    target = args.target.strip()

    if args.start < 1 or args.end > 65535:
        print("Error: ports must be between 1 and 65535.")
        sys.exit(1)

    if args.start > args.end:
        print("Error: start port must be less than or equal to end port.")
        sys.exit(1)

    if args.threads < 1:
        print("Error: threads must be at least 1.")
        sys.exit(1)

    try:
        target_ip = socket.gethostbyname(target)
    except socket.gaierror:
        print(f"Error: could not resolve hostname '{target}'.")
        sys.exit(1)

    ports = list(range(args.start, args.end + 1))
    queue: Queue = Queue()
    open_ports: List[int] = []
    lock = threading.Lock()

    print(f"Scanning {target} ({target_ip}) from port {args.start} to {args.end} using {args.threads} threads...")
    start_time = time.time()

    try:
        for port in ports:
            queue.put(port)

        threads = []
        for _ in range(min(args.threads, len(ports))):
            thread = threading.Thread(
                target=worker,
                args=(target_ip, args.timeout, queue, open_ports, lock),
            )
            thread.start()
            threads.append(thread)

        for _ in threads:
            queue.put(None)

        queue.join()

        for thread in threads:
            thread.join()

    except KeyboardInterrupt:
        print("\nScan cancelled by user.")
        sys.exit(1)

    elapsed = time.time() - start_time
    open_ports.sort()

    print(f"\nScan complete in {elapsed:.2f}s")
    if open_ports:
        print(f"Open ports found: {len(open_ports)}\n")
        for port in open_ports:
            service = get_service_name(port)
            print(f"{port}/tcp open ({service})")
    else:
        print("No open ports found in the selected range.")


if __name__ == "__main__":
    main()